package com.limemessenger.app.ui.navigation

sealed class Screen(val route: String) {
    data object Chats : Screen("chats")
    data object Favorites : Screen("favorites")
    data object Contacts : Screen("contacts")
    data object AI : Screen("ai")
    data object Settings : Screen("settings")
    data object ChatDetail : Screen("chat/{chatId}") {
        fun createRoute(chatId: String) = "chat/$chatId"
    }
    data object Profile : Screen("profile/{userId}") {
        fun createRoute(userId: String) = "profile/$userId"
    }
    data object Auth : Screen("auth")
}
