package com.limemessenger.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.limemessenger.app.ui.navigation.LimeNavHost
import com.limemessenger.app.ui.theme.LimeMessengerTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            LimeMessengerTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    LimeNavHost()
                }
            }
        }
    }
}
