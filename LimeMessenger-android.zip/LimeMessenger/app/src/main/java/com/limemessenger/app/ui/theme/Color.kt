package com.limemessenger.app.ui.theme

import androidx.compose.ui.graphics.Color

// Lime color system
val LimePrimary = Color(0xFFA8E10C)
val LimePrimaryDark = Color(0xFF7CB305)
val LimeLight = Color(0xFFD4F56A)
val LimeAccent = Color(0xFFC6F91F)
val LimeDeep = Color(0xFF5A8A00)
val LimeContainer = Color(0xFFE8F9B0)

val BackgroundLight = Color(0xFFF8FBF2)
val BackgroundDark = Color(0xFF0F0F0F)
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceDark = Color(0xFF1A1A1A)
val SurfaceVariantLight = Color(0xFFF0F5E6)
val SurfaceVariantDark = Color(0xFF252525)

val TextPrimaryLight = Color(0xFF1A1A1A)
val TextPrimaryDark = Color(0xFFF5F5F5)
val TextSecondary = Color(0xFF6B7280)
val TextSecondaryDark = Color(0xFF9CA3AF)

val BubbleOwn = Color(0xFFA8E10C)
val BubbleOtherLight = Color(0xFFF0F0F0)
val BubbleOtherDark = Color(0xFF2A2A2A)
